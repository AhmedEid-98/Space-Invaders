/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.Transition;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.effect.Bloom;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Effect;
import javafx.scene.effect.Glow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.effect.Shadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author WaterPlimpie
 */
public class StartPageController implements Initializable {
    @FXML
    private Label newGameBtn;
    @FXML
    private Label settingsBtn;
    @FXML
    private Label leaderboardBtn;
    @FXML
    private Label exitBtn;
    @FXML
    private Label titleLbl;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        exitBtn.setOnMouseClicked(e -> {
            System.exit(0);
        });
        
        newGameBtn.setOnMouseClicked(e -> {
            
            Stage newStage = new Stage();
                
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/Views/ChooseLevelPage.fxml"));
            } catch (IOException ex) {
                System.out.println("StartPageController, initialize(), load(): " + ex.getMessage());
            }

            Scene scene = new Scene(root);

            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Choose Level");
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)newGameBtn.getScene().getWindow();
            currentStage.close();
        });
        
        newGameBtn.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), newGameBtn);
            st.setFromX(1);
            st.setToX(1.5);
            st.setFromY(1);
            st.setToY(1.5);
            st.setAutoReverse(true);
            st.play();
        });
        
        newGameBtn.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), newGameBtn);
            st.setFromX(1.5);
            st.setToX(1);
            st.setFromY(1.5);
            st.setToY(1);
            st.setAutoReverse(true);
            st.play();
        });
        
        settingsBtn.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), settingsBtn);
            st.setFromX(1);
            st.setToX(1.5);
            st.setFromY(1);
            st.setToY(1.5);
            st.setAutoReverse(true);
            st.play();
        });
        
        settingsBtn.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), settingsBtn);
            st.setFromX(1.5);
            st.setToX(1);
            st.setFromY(1.5);
            st.setToY(1);
            st.setAutoReverse(true);
            st.play();
        });
        
        leaderboardBtn.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), leaderboardBtn);
            st.setFromX(1);
            st.setToX(1.5);
            st.setFromY(1);
            st.setToY(1.5);
            st.setAutoReverse(true);
            st.play();
        });
        
        leaderboardBtn.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), leaderboardBtn);
            st.setFromX(1.5);
            st.setToX(1);
            st.setFromY(1.5);
            st.setToY(1);
            st.setAutoReverse(true);
            st.play();
        });
        
        exitBtn.setOnMouseEntered(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), exitBtn);
            st.setFromX(1);
            st.setToX(1.5);
            st.setFromY(1);
            st.setToY(1.5);
            st.setAutoReverse(true);
            st.play();
            
        });
        
        exitBtn.setOnMouseExited(e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), exitBtn);
            st.setFromX(1.5);
            st.setToX(1);
            st.setFromY(1.5);
            st.setToY(1);
            st.setAutoReverse(true);
            st.play();
        });  
        
    }  
}
