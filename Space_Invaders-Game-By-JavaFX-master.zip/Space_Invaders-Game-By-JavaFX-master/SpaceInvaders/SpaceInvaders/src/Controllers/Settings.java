/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author WaterPlimpie
 */
public class Settings implements Initializable {
    @FXML
    private Button startLvl1Btn;
    @FXML
    private Button startLvl2Btn;
    @FXML
    private Button startLvl3Btn;
    @FXML
    private Button startLvl4Btn;
    @FXML
    private Button startLvl5Btn;
    @FXML
    private Button startLvl6Btn;
    @FXML
    private GridPane gridPane;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        startLvl1Btn.setOnMouseClicked(e -> {
            Stage newStage = new Stage();
                
            Parent root = null;
            FXMLLoader loader = null;
            Level1PageController controller = null;
            try {
                loader = new FXMLLoader(getClass().getResource("/Views/Level1Page.fxml"));
                root = loader.load();
                controller = loader.getController();
                System.out.println("Controller " + controller);
                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            Scene scene = new Scene(root);
            controller.afterInit(scene);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Level 1");
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)startLvl1Btn.getScene().getWindow();
            currentStage.close();
        });
        
        startLvl2Btn.setOnMouseClicked(e -> {
            Stage newStage = new Stage();
                
            Parent root = null;
            FXMLLoader loader = null;
            Level2PageController controller = null;
            try {
                loader = new FXMLLoader(getClass().getResource("/Views/Level2Page.fxml"));
                root = loader.load();
                controller = loader.getController();
                System.out.println("Controller " + controller);
                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            Scene scene = new Scene(root);
            controller.afterInit(scene);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Level 2");
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)startLvl2Btn.getScene().getWindow();
            currentStage.close();
        });
        
        startLvl3Btn.setOnMouseClicked(e -> {
             Stage newStage = new Stage();
                
            Parent root = null;
            FXMLLoader loader = null;
            Level3PageController controller = null;
            try {
                loader = new FXMLLoader(getClass().getResource("/Views/Level3Page.fxml"));
                root = loader.load();
                controller = loader.getController();
                System.out.println("Controller " + controller);
                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            Scene scene = new Scene(root);
            controller.afterInit(scene);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Level 3");
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)startLvl1Btn.getScene().getWindow();
            currentStage.close();
        });
        
        startLvl4Btn.setOnMouseClicked(e -> {
             Stage newStage = new Stage();
                
            Parent root = null;
            FXMLLoader loader = null;
            Level4PageController controller = null;
            try {
                loader = new FXMLLoader(getClass().getResource("/Views/Level4Page.fxml"));
                root = loader.load();
                controller = loader.getController();
                System.out.println("Controller " + controller);
                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            Scene scene = new Scene(root);
            controller.afterInit(scene);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Level 4");
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)startLvl1Btn.getScene().getWindow();
            currentStage.close();
        });
        
        startLvl5Btn.setOnMouseClicked(e -> {
             Stage newStage = new Stage();
                
            Parent root = null;
            FXMLLoader loader = null;
            Level5PageController controller = null;
            try {
                loader = new FXMLLoader(getClass().getResource("/Views/Level5Page.fxml"));
                root = loader.load();
                controller = loader.getController();
                System.out.println("Controller " + controller);
                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            Scene scene = new Scene(root);
            controller.afterInit(scene);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Level 5");
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)startLvl1Btn.getScene().getWindow();
            currentStage.close();
        });
        
        startLvl6Btn.setOnMouseClicked(e -> {
          Stage newStage = new Stage();
                
            Parent root = null;
            FXMLLoader loader = null;
            Level6PageController controller = null;
            try {
                loader = new FXMLLoader(getClass().getResource("/Views/Level6Page.fxml"));
                root = loader.load();
                controller = loader.getController();
                System.out.println("Controller " + controller);
                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            Scene scene = new Scene(root);
            controller.afterInit(scene);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Level 6");
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)startLvl1Btn.getScene().getWindow();
            currentStage.close();   
        });
        
        GridPane.setHalignment(startLvl1Btn, HPos.CENTER);
        GridPane.setHalignment(startLvl2Btn, HPos.CENTER);
        GridPane.setHalignment(startLvl3Btn, HPos.CENTER);
        GridPane.setHalignment(startLvl4Btn, HPos.CENTER);
        GridPane.setHalignment(startLvl5Btn, HPos.CENTER);
        GridPane.setHalignment(startLvl6Btn, HPos.CENTER);

    }    
    
}
