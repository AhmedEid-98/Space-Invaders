/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author WaterPlimpie
 */
public class GameOverPaneController implements Initializable {
    @FXML
    private Label msgLbl;
    @FXML
    private Label scoreLbl;
    @FXML
    private Label replayBtn;
    @FXML
    private Label nextBtn;
    @FXML
    private AnchorPane anchor;
    @FXML
    ImageView homeBtn;
    private boolean win;
    private IntegerProperty score = new SimpleIntegerProperty();
    private int curLvl;

    public void setWin(boolean win) {
        this.win = win;
    }

    public void setScore(int score) {
        this.score.set(score);
    }

    public void setCurLvl(int curLvl) {
        this.curLvl = curLvl;
    }
    
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        scoreLbl.textProperty().bind(score.asString());
    }    
    
    public void afterInit() {
        if (win) {
            msgLbl.setText("YOU WIN!");
        } else {
            msgLbl.setText("YOU LOSE!");
            anchor.getChildren().remove(nextBtn);
        }
        
        homeBtn.setOnMouseClicked(e -> {
            Stage newStage = new Stage();
                
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("/Views/StartPage.fxml"));                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            Scene scene = new Scene(root);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)homeBtn.getScene().getWindow();
            currentStage.close();
        });
        
        nextBtn.setOnMouseClicked(e -> {
            Stage newStage = new Stage();
            Parent root = null;
            FXMLLoader loader = null;
            LevelsController controller = null;
            try {
                loader = new FXMLLoader((getClass().getResource("/Views/Level" + (curLvl + 1) + "Page.fxml")));
                root = loader.load();
                controller = loader.getController();
                
                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
            
            Scene scene = new Scene(root);
            controller.afterInit(scene);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Game Over");
            newStage.setScene(scene);
            newStage.show();
            Stage currentStage = (Stage)anchor.getScene().getWindow();
            currentStage.close();
        });
        
        replayBtn.setOnMouseClicked(e -> {
            Stage newStage = new Stage();
            Parent root = null;
            FXMLLoader loader = null;
            LevelsController controller = null;
            try {
                loader = new FXMLLoader((getClass().getResource("/Views/Level" + (curLvl) + "Page.fxml")));
                root = loader.load();
                controller = loader.getController();
                
                
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
            
            Scene scene = new Scene(root);
            controller.afterInit(scene);
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Game Over");
            newStage.setScene(scene);
            newStage.show();
            Stage currentStage = (Stage)anchor.getScene().getWindow();
            currentStage.close();
        });
    }
}
