/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controllers;

import Models.Bullet;
import Models.Enemy;
import Models.EnemyBullet;
import Models.Player;
import java.awt.AWTException;
import java.awt.MouseInfo;
import java.awt.Robot;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.AnimationTimer;
import javafx.animation.TranslateTransition;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author WaterPlimpie
 */
public class Level2PageController extends LevelsController implements Initializable {
    @FXML
    private AnchorPane anchor;
    @FXML
    private Label exitBtn;
    @FXML
    private Label scoreLbl;
    @FXML
    private Line topBorder, bottomBorder, leftBorder, rightBorder;

    private Player player;

    //private Scene scene;

    private IntegerProperty score;

    private ArrayList<Enemy> enemies;

    private ArrayList<Bullet> bullets;
    private ArrayList<EnemyBullet> enemyBullets;
    
    private BooleanProperty leftPressed, rightPressed, upPressed, downPressed, mousePressed, 
            aPressed, dPressed;
    
    private BooleanBinding keyPressed;
    AnimationTimer clickTimer;
    AnimationTimer timer;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO add invisible labels to the sides of the pane to detect bullets leaving the perimeter, and make them dead on collision
        // TODO add bounds to the player's movement
        // TODO create the game over menu
        // TODO set sounds on explosions
        
        
        leftPressed = new SimpleBooleanProperty(false);
        rightPressed = new SimpleBooleanProperty(false);
        downPressed = new SimpleBooleanProperty(false);
        upPressed = new SimpleBooleanProperty(false);
        mousePressed = new SimpleBooleanProperty(false);
        aPressed = new SimpleBooleanProperty(false);
        dPressed = new SimpleBooleanProperty(false);

        keyPressed = leftPressed.or(rightPressed).or(downPressed).or(upPressed).or(mousePressed).or(aPressed).or(dPressed);
        clickTimer = new AnimationTimer() {
            private long lastUpdate = 0 ;
            @Override
            public void handle(long now) {
                if (leftPressed.get()) {
                    player.moveLeft();
                }
                if (rightPressed.get()) {
                    player.moveRight();
                }
                if (upPressed.get()) {
                    player.moveUp();
                }
                if (downPressed.get()) {
                    player.moveDown();
                }
                if (aPressed.get()) {
                    player.rotateLeft();
                }
                if (dPressed.get()) {
                    player.rotateRight();
                }
               if (now - lastUpdate >= 500_000_000 && mousePressed.get()) {
                   lastUpdate = now;
                   Bullet b = new Bullet();
                    b.setVelocity(player.getVelocity().normalize().multiply(10));
                    bullets.add(b);
                    b.getView().setTranslateX(player.getView().getTranslateX());
                    b.getView().setTranslateY(player.getView().getTranslateY());
                    b.getView().setRotate(player.getRotate());
                    anchor.getChildren().add(b.getView());
                    System.out.println("bullets: " + bullets.size());
               }
            }
            
        };
        keyPressed.addListener((o, old, nw) -> {
            if(nw) {
                clickTimer.start();
            } else {
                clickTimer.stop();
            }
        });
        
        // Change the 3rd parameter to change the health.
        player = new Player(400, 500, 7);
        //
        //player.getView().setTranslateX(400);
        //player.getView().setTranslateY(500);
        
        


        score = new SimpleIntegerProperty(0);
        scoreLbl.textProperty().bind(score.asString());

        enemies = new ArrayList<>();

        bullets = new ArrayList<>();
        
        enemyBullets = new ArrayList<>();

        
        for (int i = 0; i < 4; ++i) {
            for (int j = 0; j < 3; ++j) {
                Enemy e = new Enemy(220 + (i * 220), 50 + (100 * j), 2);

                TranslateTransition t = new TranslateTransition(Duration.millis(1000), e.getView());
                t.setCycleCount(Animation.INDEFINITE);
                t.setAutoReverse(true);
                t.setByX((j % 2 == 0) ? 170 : -170 );
                t.play();
                
                TranslateTransition th = new TranslateTransition(Duration.millis(1000), e.getHealthBar());
                th.setCycleCount(Animation.INDEFINITE);
                th.setAutoReverse(true);
                th.setByX((j % 2 == 0) ? 170 : -170 );
                th.play();
                enemies.add(e);
            }
        }
        

        for (Enemy e : enemies) {
            anchor.getChildren().add(e.getView());
            anchor.getChildren().add(e.getHealthBar());
        }

        anchor.getChildren().add(player.getView());
        anchor.getChildren().add(player.getHealthBar());

        exitBtn.setOnMouseClicked(e-> {
            //System.exit(0);
            Stage currentStage = (Stage)anchor.getScene().getWindow();
                currentStage.close();
        });

        timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                player.getView().setTranslateX(MouseInfo.getPointerInfo().getLocation().getX());
                player.getView().setTranslateY(MouseInfo.getPointerInfo().getLocation().getY());
                player.getHealthBar().setTranslateX(MouseInfo.getPointerInfo().getLocation().getX());
                player.getHealthBar().setTranslateY(MouseInfo.getPointerInfo().getLocation().getY()- 10);
                onUpdate();
            }
        };
        timer.start();

        exitBtn.toFront();
    }

    public void afterInit(Scene scene) {
        try {
            Robot robot = new Robot();
            robot.mouseMove(1280/2, 600);
            
        } catch (AWTException ex) {
        }
        try {
            Thread.sleep(2000);
            //this.scene = scene;
        } catch (InterruptedException ex) {
        }
        
        //scene = exitBtn.getScene();
        scene.setOnMousePressed(e -> {
            mousePressed.set(true);
        });
        scene.setOnMouseReleased(e -> {
            mousePressed.set(false);
        });
        scene.setOnKeyPressed(e -> {
             switch (e.getCode()) {
                 case ESCAPE:
                     System.exit(0);
                 case LEFT:
                     leftPressed.set(true);
                     //player.moveLeft();
                     break;
                 case RIGHT:
                     //player.moveRight();
                     rightPressed.set(true);
                     break;
                 case UP:
                     //player.moveUp();
                     upPressed.set(true);
                     break;
                 case DOWN:
                     //player.moveDown();
                     downPressed.set(true);
                     break;
                 case A:
                     //player.rotateLeft();
                     aPressed.set(true);
                     break;
                 case D:
                     //player.rotateRight();
                     dPressed.set(true);
                     break;
                 case SPACE:
                     mousePressed.set(true);

             }
        });
        
        scene.setOnKeyReleased(e -> {
             switch (e.getCode()) {
                 case LEFT:
                     //player.moveLeft();
                     leftPressed.set(false);
                     break;
                 case RIGHT:
                     //player.moveRight();
                     rightPressed.set(false);
                     break;
                 case UP:
                     //player.moveUp();
                     upPressed.set(false);
                     break;
                 case DOWN:
                     //player.moveDown();
                     downPressed.set(false);
                     break;
                 case A:
                     //player.rotateLeft();
                     aPressed.set(false);
                     break;
                 case D:
                     dPressed.set(false);
                     //player.rotateRight();
                     break;
                 case SPACE:
                     mousePressed.set(false);
             }
        });
        
        
         scene.setCursor(Cursor.NONE);
//         scene.setOnMouseMoved(e -> {
//             //Point2D pnt = new Point2D(e.getSceneX(), e.getSceneY());
//             Point2D pnt = new Point2D(e.getSceneX(), e.getSceneY());
//             player.getView().setTranslateX(pnt.getX() - 38);
//             player.getView().setTranslateY(pnt.getY() - 10);
//         });
         
    }

    private void onUpdate() {
        for (Enemy e : enemies) {
            if (e.isColliding(player)) {
                if (!player.updateHealth()) {
                    gameOver(false);
                    timer.stop();
                    break;
                }
            }
            Random r = new Random();
                if (r.nextDouble() < 0.001) {
                    EnemyBullet eb = new EnemyBullet(5);
                    eb.getCircle().setTranslateX(e.getView().getTranslateX() + (e.getView().getFitWidth() / 2));
                    eb.getCircle().setTranslateY(e.getView().getTranslateY() + 50);
                    anchor.getChildren().add(eb.getCircle());
                    enemyBullets.add(eb);
                }
        }
        for (Bullet b : bullets) {
            if (b.isColliding(topBorder) || b.isColliding(bottomBorder) || b.isColliding(rightBorder) || b.isColliding(leftBorder)) {
                b.setAlive(false);
                anchor.getChildren().remove(b.getView());
                continue;
            }
            for (Enemy e : enemies) {
                if (b.isColliding(e)) {
                    if (!e.updateHealth()) {
                        e.setAlive(false);
                        anchor.getChildren().removeAll(e.getHealthBar(), e.getView());
                        score.set(score.get() + 1);
                        if (score.get() == 12) {
                            gameOver(true);
                            timer.stop();
                            break;
                        }
                    }
                    //e.setAlive(false);
                    b.setAlive(false);
                    anchor.getChildren().removeAll(b.getView());

                    
                    //System.out.println(score.get() + " " + scoreLbl.getText());
                }
            }
        }
        for (EnemyBullet b : enemyBullets) {
            if (b.isColliding(topBorder) || b.isColliding(bottomBorder) || b.isColliding(rightBorder) || b.isColliding(leftBorder)) {
                b.setAlive(false);
                anchor.getChildren().remove(b.getCircle());
            }
            if (b.isColliding(player)) {
                b.setAlive(false);
                anchor.getChildren().remove(b.getCircle());
                if (!player.updateHealth()) {
                    gameOver(false);
                    timer.stop();
                    break;
                }
            }
        }
        bullets.removeIf(Bullet::isDead);
        enemies.removeIf(Enemy::isDead);
        enemyBullets.removeIf(EnemyBullet::isDead);

        bullets.forEach(Bullet::update);
        enemyBullets.forEach(EnemyBullet::update);
    }

    private void gameOver(boolean win) {
        enemies.forEach((e) -> {
            anchor.getChildren().removeAll(e.getHealthBar(), e.getView());
        });
        bullets.forEach(b -> anchor.getChildren().remove(b.getView()));
        enemyBullets.forEach(b -> anchor.getChildren().remove(b.getCircle()));
        anchor.getChildren().removeAll(player.getHealthBar(), player.getView());
        
        if (win)
            System.out.println("win");
        
            Stage newStage = new Stage();
                
            Parent root = null;
            FXMLLoader loader = null;
            GameOverPaneController controller = null;
            try {
                loader = new FXMLLoader(getClass().getResource("/Views/GameOverPane.fxml"));
                root = loader.load();
                controller = loader.getController();
                System.out.println("Controller " + controller);
                controller.setCurLvl(2);
                controller.setScore(score.get());
                controller.setWin(win);
                controller.afterInit();
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }

            Scene scene = new Scene(root);
            
            newStage.initStyle(StageStyle.UNDECORATED);
            newStage.setTitle("Game Over");
            newStage.setScene(scene);
            newStage.show();

            Stage currentStage = (Stage)anchor.getScene().getWindow();
            currentStage.close();
    }

}
