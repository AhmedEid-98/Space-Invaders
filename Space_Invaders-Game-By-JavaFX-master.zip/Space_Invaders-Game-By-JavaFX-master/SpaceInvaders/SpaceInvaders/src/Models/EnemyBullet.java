package Models;

import java.util.Random;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;


public class EnemyBullet {
    
    private Circle circle;
    private boolean alive;
    private int speed;
    
    public EnemyBullet(int speed) {
        circle = new Circle();
        circle.setRadius(10);
        circle.setFill(Color.YELLOW);
        this.speed = speed;
        alive = true;
    }

    public Circle getCircle() {
        return circle;
    }

    public void setCircle(Circle circle) {
        this.circle = circle;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }
    
    public boolean isDead() {
        return !alive;
    }
    
    public boolean isColliding(Player p) {
        return circle.getBoundsInParent().intersects(p.getView().getBoundsInParent());
    }
    
    public boolean isColliding(Line l) {
        return circle.getBoundsInParent().intersects(l.getBoundsInParent());
    }
    
    public void update() {
        circle.setTranslateY(circle.getTranslateY() + new Random().nextInt(speed));
    }
}
