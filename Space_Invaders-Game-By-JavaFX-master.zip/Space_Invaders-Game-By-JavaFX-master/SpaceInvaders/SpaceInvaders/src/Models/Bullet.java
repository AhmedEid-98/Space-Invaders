package Models;

import javafx.geometry.Point2D;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Line;


public class Bullet {
    
    private ImageView view;
    private Point2D velocity;
    private boolean alive;
    
    public Bullet() {
        view = new ImageView("/Resources/bullet.png");
        view.setFitHeight(50);
        view.setPreserveRatio(true);
        
        alive = true;
    }

    public boolean isAlive() {
        return alive;
    }
    
    public boolean isDead() {
        return !alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }
    
    public Point2D getVelocity() {
        return velocity;
    }

    public void setVelocity(Point2D velocity) {
        this.velocity = velocity;
    }

    public ImageView getView() {
        return view;
    }
    
    
    public boolean isColliding(Enemy other) {
        return getView().getBoundsInParent().intersects(other.getView().getBoundsInParent());
    }
    
    public boolean isColliding(Line other) {
        return getView().getBoundsInParent().intersects(other.getBoundsInParent());
    }
    
    public void update() {
        view.setTranslateX(view.getTranslateX() + velocity.getY());
        view.setTranslateY(view.getTranslateY() - velocity.getX());
    }
}
