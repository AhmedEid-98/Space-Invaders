/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import static javafx.animation.Animation.INDEFINITE;
import javafx.animation.ParallelTransition;
import javafx.animation.TranslateTransition;
import javafx.geometry.Rectangle2D;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

/**
 *
 * @author WaterPlimpie
 */
public class Enemy {
    private final ImageView view;
    private boolean alive;
    private int health;
    private int currentHealth;
    private Rectangle healthBar;
    //private Point2D velocity;
    //private int movement = 20;
    public Enemy(int x, int y, int health) {
        view = new ImageView("/Resources/enemy.png");
        //view.setFitHeight(50);
        view.setFitWidth(150);
        view.setPreserveRatio(true);
        
        view.setTranslateX(x);
        view.setTranslateY(y);
        alive = true;
        
        this.health = health;
        currentHealth = health;
        makeHealthBar();
    }
    
    private void makeHealthBar() {
        healthBar = new Rectangle(view.getX(), view.getY(), view.getFitWidth(), 5);
        healthBar.setArcHeight(15);
        healthBar.setArcWidth(15);
        healthBar.setTranslateX(view.getTranslateX());
        healthBar.setTranslateY(view.getTranslateY() - 10);
        healthBar.setFill(Color.RED);
    }

    public int getHealth() {
        return health;
    }
        
    public boolean isDead() {
        return !alive;
    }
    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    public ImageView getView() {
        return view;
    }

    public Rectangle getHealthBar() {
        return healthBar;
    }

    public void setHealthBar(Rectangle healthBar) {
        this.healthBar = healthBar;
    }
    
    public boolean updateHealth() {
        --currentHealth;
        healthBar.setWidth(150.0 * currentHealth / health);
        return currentHealth > 0;
    }
    
    public boolean isColliding(Player p) {
        return view.getBoundsInParent().intersects(p.getView().getBoundsInParent());
    }
}
