/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

/**
 *
 * @author WaterPlimpie
 */
public class Player {
    private final ImageView view;
    private boolean alive;
    private Point2D velocity;
    private int health;
    private int currentHealth;
    private Rectangle healthBar;
    private int movement = 10;
    
    public Player(int x, int y, int health) {
        //set the player's image
        view = new ImageView("/Resources/player.png");
        view.setFitHeight(75);
        view.setPreserveRatio(true);
        view.setTranslateX(x);
        view.setTranslateY(y);
        alive = true;
        velocity = new Point2D(1, 0);
        
        this.health = health;
        currentHealth = health;
        makeHealthBar();
        
    }

    public Rectangle getHealthBar() {
        return healthBar;
    }
    
    private void makeHealthBar() {
        healthBar = new Rectangle(view.getX(), view.getY(), 75, 5);
        healthBar.setArcHeight(15);
        healthBar.setArcWidth(15);
        healthBar.setTranslateX(view.getTranslateX());
        healthBar.setTranslateY(view.getTranslateY() - 10);
        healthBar.setFill(Color.GREEN);
        
    }
    
    public boolean updateHealth() {
        System.out.println("hit");
        --currentHealth;
        healthBar.setWidth(75 * currentHealth / health);
        return currentHealth > 0;
    }

    public Point2D getVelocity() {
        return velocity;
    }

    public void setVelocity(Point2D velocity) {
        this.velocity = velocity;
    }
    
    public ImageView getView() {
        return view;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }
    
    public void moveRight() {
        TranslateTransition t = new TranslateTransition(Duration.millis(1), view);
        t.setByX(movement);
        t.setCycleCount(1);
        t.play();
        
        TranslateTransition th = new TranslateTransition(Duration.millis(1), healthBar);
        th.setByX(movement);
        th.setCycleCount(1);
        th.play();
    }
    
    public void moveLeft() {
        TranslateTransition t = new TranslateTransition(Duration.millis(1), view);
        t.setByX(-movement);
        t.setCycleCount(1);
        t.play();
        
        TranslateTransition th = new TranslateTransition(Duration.millis(1), healthBar);
        th.setByX(-movement);
        th.setCycleCount(1);
        th.play();
    }
    
    public void moveUp() {
        TranslateTransition t = new TranslateTransition(Duration.millis(1), view);
        t.setByY(-movement);
        t.setCycleCount(1);
        t.play();
        
        TranslateTransition th = new TranslateTransition(Duration.millis(1), healthBar);
        th.setByY(-movement);
        th.setCycleCount(1);
        th.play();
    }
    
    public void moveDown() {
        TranslateTransition t = new TranslateTransition(Duration.millis(1), view);
        t.setByY(movement);
        t.setCycleCount(1);
        t.play();
        
        TranslateTransition th = new TranslateTransition(Duration.millis(1), healthBar);
        th.setByY(movement);
        th.setCycleCount(1);
        th.play();
    }
    
    public double getRotate() {
        return view.getRotate();
    }

    public void rotateRight() {
        healthBar.setRotate(view.getRotate() + 5);
        view.setRotate(view.getRotate() + 5);
        setVelocity(new Point2D(Math.cos(Math.toRadians(getRotate())), Math.sin(Math.toRadians(getRotate()))));
    }

    public void rotateLeft() {
        healthBar.setRotate(view.getRotate() - 5);
        view.setRotate(view.getRotate() - 5);
        setVelocity(new Point2D(Math.cos(Math.toRadians(getRotate())), Math.sin(Math.toRadians(getRotate()))));
    }
    
}
